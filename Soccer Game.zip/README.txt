Extract all the files to any spare folder. 

Run 'Runner.exe' file to start the game. The game will enter fullscreen mode.

Close the game by closing the window, right-clicking on the Unity icon. 

You may have to use the 'Windows' key if you are using Windows.